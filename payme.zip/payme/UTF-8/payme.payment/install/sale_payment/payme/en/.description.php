<?
global $MESS;
$MESS["PAYME_MERCHANT"] = "Merchant Id";
$MESS["PAYME_MERCHANT_DEF"] = "Merchant Id";
$MESS["PAYME_SECURE_KEY"] = "Key - checkout password";
$MESS["PAYME_SECURE_KEY_DEF"] = "Key - checkout password";
$MESS["PAYME_SECURE_KEY_TEST"] = "Key - checkout password for test";
$MESS["PAYME_SECURE_KEY_TEST_DEF"] = "Key - checkout password for test";
$MESS["PAYME_SERVER_URL"] = "Url for Payme";
$MESS["PAYME_TEST_MODE"] = "Enable test mode";
$MESS["PAYME_CHECKOUT_URL"] = "URL gateway";
$MESS["PAYME_CHECKOUT_URL_TEST"] = "URL gateway for test";
$MESS["PAYME_PRINT_CHECK"] ="Add information about products to check";
$MESS["PAYME_YES"] ="Yes";
$MESS["PAYME_NO"]  ="No";
$MESS["PAYME_CALLBACK"] = "Return after payment";
$MESS["INSTANTLY"] = "Instantly";
$MESS["S15"] = "15 seconds";
$MESS["S30"] = "30 seconds";
$MESS["S60"] = "60 seconds";
$MESS["SITE_BACK_URL"] = "Redirection URL";
$MESS["PAYME_END_POINT_URL"] = "End Point Url";
?>