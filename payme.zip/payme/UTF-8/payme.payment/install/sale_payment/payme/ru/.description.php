<?
global $MESS;
$MESS["PAYME_MERCHANT"] = "ID поставщика";
$MESS["PAYME_MERCHANT_DEF"] = "Идентификатор мерчанта";
$MESS["PAYME_SECURE_KEY"] = "Ключ - пароль кассы";
$MESS["PAYME_SECURE_KEY_DEF"] = "Секретный ключ";
$MESS["PAYME_SECURE_KEY_TEST"] = "Ключ - пароль для тестов";
$MESS["PAYME_SECURE_KEY_TEST_DEF"] = "Секретный ключ";
$MESS["PAYME_SERVER_URL"] = "Url для Payme";
$MESS["PAYME_TEST_MODE"] = "Включить режим тестирования";
$MESS["PAYME_CHECKOUT_URL"] = "Введите URL-адрес шлюза";
$MESS["PAYME_CHECKOUT_URL_TEST"] = "Введите URL-адрес шлюза для теста";
$MESS["PAYME_PRINT_CHECK"] ="Добавить в чек данные о товарах";
$MESS["PAYME_YES"] ="Да";
$MESS["PAYME_NO"]  ="Нет";
$MESS["PAYME_CALLBACK"] = "Вернуться после оплаты через";
$MESS["INSTANTLY"] = "Моментально";
$MESS["S15"] = "15 секунд";
$MESS["S30"] = "30 секунд";
$MESS["S60"] = "60 секунд";
$MESS["SITE_BACK_URL"] = "Вернуться после оплаты на";
$MESS["PAYME_END_POINT_URL"] = "End Point Url";
?>