<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface/include/sale_payment/payme/notification.php");
?>