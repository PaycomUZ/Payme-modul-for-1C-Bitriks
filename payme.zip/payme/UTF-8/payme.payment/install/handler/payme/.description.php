<?php
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/payme.payment/install/sale_payment/payme/.description.php");
?>