<?php
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/payme.payment/install/sale_payment/payme/api/PaymeApi.php");
?>