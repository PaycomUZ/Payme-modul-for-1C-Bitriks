<?
$arModuleVersion = array(

	"VERSION" => "1.0.0 (utf-8)",
	"VERSION_DATE" => "2019-05-09"
);
?>