<?php
$MESS["PAYME_MODULE_NAME"] = "Payme.uz";
$MESS["PAYME_MODULE_DESC"] = "Payme.uz платёжный модуль для Bitrix CMS: \"Small business\", \"Business\" и \"Business web-cluster\".";
?>