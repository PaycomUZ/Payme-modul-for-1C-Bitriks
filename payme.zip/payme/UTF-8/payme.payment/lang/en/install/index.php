<?php
$MESS["PAYME_MODULE_NAME"] = "Payma.uz";
$MESS["PAYME_MODULE_DESC"] = "Payma.uz payment module for Bitrix CMS: \"Small business\", \"Business\" and \"Business web-cluster\".";
?>