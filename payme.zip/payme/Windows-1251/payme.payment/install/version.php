<?
$arModuleVersion = array(

	"VERSION" => "1.0.0 (windows-1251)",
	"VERSION_DATE" => "2019-05-09"
);
?>